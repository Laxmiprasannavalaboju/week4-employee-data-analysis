import argparse
from pathlib import Path

import pandas as pd


def analyze_employee_data(csv_path: Path, salary_threshold: float, output_path: Path) -> None:
    """Load employee data, calculate summary statistics, filter employees, and export results."""
    if not csv_path.exists():
        raise FileNotFoundError(f"Dataset not found: {csv_path}")

    df = pd.read_csv(csv_path)

    required_columns = {"Name", "Department", "Salary"}
    missing = required_columns - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {', '.join(sorted(missing))}")

    average_salary = df["Salary"].mean()
    department_count = df["Department"].value_counts().sort_index()
    above_threshold = df[df["Salary"] > salary_threshold].copy()

    output_path.parent.mkdir(parents=True, exist_ok=True)
    above_threshold.to_csv(output_path, index=False)

    print("=== Employee Data Analysis ===")
    print(f"Total employees: {len(df)}")
    print(f"Average salary: ${average_salary:,.2f}")
    print("\nEmployees by department:")
    print(department_count.to_string())
    print(f"\nEmployees earning more than ${salary_threshold:,.2f}:")
    if above_threshold.empty:
        print("None")
    else:
        print(above_threshold.to_string(index=False))
    print(f"\nFiltered results exported to: {output_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Analyze employee data with Pandas.")
    parser.add_argument("--input", type=Path, default=Path("data/employees.csv"))
    parser.add_argument("--threshold", type=float, default=70000)
    parser.add_argument(
        "--output", type=Path, default=Path("output/employees_above_threshold.csv")
    )
    args = parser.parse_args()

    analyze_employee_data(args.input, args.threshold, args.output)


if __name__ == "__main__":
    main()
